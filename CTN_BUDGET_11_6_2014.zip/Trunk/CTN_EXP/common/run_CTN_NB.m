
%RUN_CTN_NB  Script to run the CTN NoiseBudget demo

%% Path setup

if exist('NbSVNroot.m', 'file') == 2 && exist('ctnData.m', 'file') == 2
    % path is already OK
else
    parent = fileparts(fileparts(fileparts(mfilename('fullpath'))));
    addpath(genpath([parent filesep 'Common' filesep 'Utils']));
    addpath(genpath([parent filesep 'CTN_EXP']));
end

%% Load parameters, linearize the model, and extract noise terms

disp('Loading parameters for the CTN Simulink model')
ctnParams;
ctnNbParams;
% [noises, sys] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'ServoOut_00');
% [noises, sys] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'ServoOut_02');
%[noises, sys] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'ServoOut_20');
% [noises, sys] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'beat02');
%[noises, sys] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'TF2');
[noises, sys] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', '00');
% [noises, sys] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'BeatNote');
%% Make a quick NB plot

disp('Plotting noises')
nb = nbGroupNoises('ctnFCS', noises, sys);
nb.sortModel();
% matlabNoisePlot(nb);

%% bode plots
bops = bodeoptions;
bops.FreqUnits = 'Hz';

% TF for calibration
figure(101)
bodeplot(sys(1),bops)

% TFs for each noise source to noise sink
for n = 2:length(sys.d)
    figure(100+n)
    bodeplot(sys(n),bops)
end