
clear
open_system('ctnFCS')
ctnParams;
ctnNbParams;
% io(1)=linio('ctnFCS/00 FCL/Sum1',1,'openinput');
% io(2)=linio('ctnFCS/00 FCL/Servo',1,'openoutput');
io(1)=linio('ctnFCS/00 FCL/Sum1',1,'looptransfer');
%io(1)=linio('ctnFCS/00 FCL/Sum1',1,'compsensitivity');

setlinio('ctnFCS',io);
%setlinio('ctnFCS/00 FCL',io)
systest = linearize('ctnFCS',io);
figure(200)
bode(systest)


figure(100)
semilogx(fcsParams.freq,fcsParams.TF.TFmag00)
grid on
hold on

gain00        = -33.92;                         % dB measured gain at 
freq00        = 8e4;                            % Hz this trequency
fcsParams.servo00.zeros       = [10e3];         % Hz
fcsParams.servo00.poles       = [0,0];          % Hz
fcsParams.servo00.gain        = find_K(fcsParams.servo00.zeros,...
                                       fcsParams.servo00.poles,...
                                       gain00, freq00);  

k = 10^(fcsParams.servo00.gain/20);   % unitless
G=freqresp(zpk(-2 * pi * fcsParams.servo00.zeros, -2 * pi * fcsParams.servo00.poles,k),fcsParams.freq,'Hz');

for ii= 1:size(fcsParams.freq,2)    
    g(ii)= 20*log10(abs(G(1,1,ii))); 
end
semilogx(fcsParams.freq,g,'r')






clear
open_system('ctnFCS')
ctnParams;
ctnNbParams;
%  io(1)=linio('ctnFCS/SystemNoise/Sum1',1,'openinput');
%  io(2)=linio('ctnFCS/02 FCL/Cavity02/Sum1',1,'openoutput');
%io(2)=linio('ctnFCS/02 FCL/Cavity02/Sum2',1,'openoutput');
io(1)=linio('ctnFCS/02 FCL/Sum1',1,'looptransfer');

%io(1)=linio('ctnFCS/02 FCL/Cavity02/Sum1',1,'compsensitivity');   % 02 

setlinio('ctnFCS',io);
%setlinio('ctnFCS/00 FCL',io)
systest = linearize('ctnFCS',io);
figure(200)
bode(systest)





clear
open_system('ctnFCS')
ctnParams;
ctnNbParams;
%  io(1)=linio('ctnFCS/SystemNoise/Sum1',1,'openinput');
%  io(2)=linio('ctnFCS/20 FCL/Cavity20/Sum1',1,'openoutput');
%io(2)=linio('ctnFCS/20 FCL/Cavity20/Sum2',1,'openoutput');
io(1)=linio('ctnFCS/20 FCL/Sum1',1,'looptransfer');

%io(1)=linio('ctnFCS/02 FCL/Cavity02/Sum1',1,'compsensitivity');   % 02 

setlinio('ctnFCS',io);
systest = linearize('ctnFCS',io);
figure(200)
bode(systest)

 



clear
open_system('test')

  %io(1)=linio('test/Gain1',1,'openinput');
  %io(2)=linio('test/Gain2',1,'openoutput');
%io(1)=linio('test/Gain',1,'sensitivity');
io(1)=linio('test/Gain',1,'looptransfer');
%io(1)=linio('test/Gain',1,'compsensitivity');
%io(1)=linio('ctnFCS/02 FCL/Cavity02/Sum1',1,'compsensitivity');   % 02 

setlinio('test',io);
%setlinio('ctnFCS/00 FCL',io)
systest = linearize('test',io);
figure(103)
bode(systest)




 
