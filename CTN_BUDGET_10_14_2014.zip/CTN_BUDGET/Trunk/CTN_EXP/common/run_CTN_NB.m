


%RUN_CTN_NB  Script to run the DARM NoiseBudget demo

%% Path setup

findNbSVNroot;
addpath(genpath([NbSVNroot 'Common/Utils']));

%% Load parameters, linearize the model, and extract noise terms

disp('Loading parameters for the CTN Simulink model')
ctnParams;
ctnNbParams;
[noises, sys, tfs] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'ServoIN_00');
%[noises, sys, tfs] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'ServoIN_02');
%[noises, sys, tfs] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'ServoIN_20');
%[noises, sys, tfs] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'beat02');
%[noises, sys, tfs] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'TF2');
%[noises, sys, tfs] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', '00');
%[noises, sys, tfs] = nbFromSimulink('ctnFCS', fcsParams.freq, 'dof', 'CTN');
%% Make a quick NB plot

disp('Plotting noises')
nb = nbGroupNoises('ctnFCS', noises, sys);
nb.sortModel();
matlabNoisePlot(nb);