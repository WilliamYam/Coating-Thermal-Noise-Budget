function par = omcparams()

    par.constants.hnu = 6.626e-34*3e8/1064e-9;


    par.Pin = 3.5e-3; %Input power [W]

    par.Tbs = 0.5; % Beam splitter power transmission
    
    par.resp.A = 0.72; % Photodiode A responsivity [A/W]
    par.resp.B = 0.75; % Photodiode B responsivity [A/W]
    
    highZ = 400; % High-transimpedance state [V/A]
    lowZ = 100; % Low-transimpedance state [V/A]
    
    par.transZ.A = lowZ; % DCPD A transimpedance [V/A]
    par.transZ.B = lowZ; % DCPD B transimpedance [V/A]
    
    load ../L1/DCPD/DCPD_TFs_L1.mat % Load measured L1 preamp TFs [V/V]
    par.preampA = tf006;
    par.preampB = tf008;
    
    par.A2D = 2^16 /40; % ADC gain
    


end