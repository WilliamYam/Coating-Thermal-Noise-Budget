function ctnNbParams
%CTNNBPARAMS  Defines noises for the HOM20.mdl Simulink NoiseBudget
%
% It outputs to a variable called "fcsParams.ctbNb" in the matlab workspace.
%% Setup and meta-parameters

fcsParams = evalin('base', 'fcsParams');

fcsParams.ctnNb.meta.paramsFileName = mfilename('fullpath');
fcsParams.ctnNb.meta.name = 'HOM20';

if exist('NbSVNroot.m', 'file') ~= 2
    error('Please add the NbSVN''s Common/Utils folder to your MATLAB path');
end

noiseModelDir = [NbSVNroot 'Trunk\Common\Utils\NoiseModel'];    %important to have it
ModelDir = [NbSVNroot 'CTN_EXP\Data\'];                  % storage data directory                 
currentDir = pwd;

%%  Data loading

cd(ModelDir)
load('ctnData.mat') 
cd(currentDir)

%% Laser Noise

% units: Hz/rtHz
% typical value for NPRO 1/f noise

fcsParams.ctnNb.LaserFreqNoise = 100;                    % [Hz/rtHz] @100Hz - laser frequency noise 

%% PD shot noise
% units: Hz/rtHz
% estimated from the incident power on PD when cavity locked

     %%%-------definition of PD shot noise-------------------------------
     ShotNoise = @(pPD,hPlanck,fLight)(sqrt(2 * pPD * hPlanck * fLight));    % W/rtHz at PD
     %--------------------------------------------------------------------


%%% 1811 (Gaussian)
pPD = fcsParams.beam.PwrInc00 * (1 - fcsParams.beam.Coupling00); % W ( 
fcsParams.ctnNb.PDshotNoise00 = ShotNoise(pPD,fcsParams.common.h,...
                                        fcsParams.common.laserFreq);
%%%LSCPD (HOM02)
pPD = fcsParams.beam.PwrInc02 * (1 - fcsParams.beam.Coupling02);         % W/rtHz at PD  
fcsParams.ctnNb.PDshotNoise02 = ShotNoise(2*pPD,fcsParams.common.h,...
                                        fcsParams.common.laserFreq);
%%%LSCPD (HOM20)
pPD = fcsParams.beam.PwrInc20 * (1 - fcsParams.beam.Coupling20);         % W (for shot noise for 00, power on PD when locked)
fcsParams.ctnNb.PDshotNoise20 = ShotNoise(2*pPD,fcsParams.common.h,...
                                        fcsParams.common.laserFreq);
                                    
%% PD dark noise
% deatils in ctnData.m
fcsParams.ctnNb.n00PDOut = interp1(n00PDServoIn(:,1),n00PDServoIn(:,2),fcsParams.freq);
%   figure(50)
%   loglog(n00PDServoIn(:,1),n00PDServoIn(:,2),'r')
%   hold on
%   loglog(fcsParams.freq,fcsParams.ctnNb.n00PDServoIn)
fcsParams.ctnNb.n02PDOut = interp1(n02PDServoIn(:,1),n02PDServoIn(:,2),fcsParams.freq);
fcsParams.ctnNb.n20PDOut = interp1(n20PDServoIn(:,1),n20PDServoIn(:,2),fcsParams.freq);

%% Servo
% deatils in ctnData.m
%fcsParams.ctnNb.n00sServoOut = n00sServoOut;       %missing freq row
fcsParams.ctnNb.n00sServoOut = interp1(n00sServoOut(:,1),n00sServoOut(:,2),fcsParams.freq); 
fcsParams.ctnNb.n02sServoOut = interp1(n02sServoOut(:,1),n02sServoOut(:,2),fcsParams.freq); 
fcsParams.ctnNb.n20sServoOut = interp1(n20sServoOut(:,1),n20sServoOut(:,2),fcsParams.freq); 

%% VCO (Marconi)
% deatils in ctnData.m
%fcsParams.ctnNb.n02Marconi = n02Marconi * fcsParams.OptGain.PhaseDetectorGain;           % Hz/rtHz
fcsParams.ctnNb.n02Marconi = interp1(n02Marconi(:,1),n02Marconi(:,2),fcsParams.freq)/...
                             fcsParams.OptGain.PhaseDetectorGain02;                       % Hz/rtHz
fcsParams.ctnNb.n20Marconi = interp1(n02Marconi(:,1),n02Marconi(:,2),fcsParams.freq)/...
                             fcsParams.OptGain.PhaseDetectorGain20;                       % Hz/rtHz
                         
%% Length Noise (model)

fcsParams.ctnNb.noiseLength = 1e-11./ (1 + (fcsParams.freq / 100).^2);                   % m / rtHz cavity length noise

%%CTN
fcsParams.ctnNb.CTN = sqrt(2)*3.6e-18 .* sqrt(100./ fcsParams.freq)*100/61;      % [m/rtHz] predicted coating thermal noise
                         
%% Total Noise
% deatils in ctnData.m

%%%Gaussian
fcsParams.ctnNb.nTotServoIn00 = interp1(n00totServoIn(:,1),n00totServoIn(:,2),fcsParams.freq);
fcsParams.ctnNb.nTotServoOut00 = interp1(n00totServoOut(:,1),n00totServoOut(:,2),fcsParams.freq);
%%%HOM02
fcsParams.ctnNb.nTotServoIn02 = interp1(n02totServoIn(:,1),n02totServoIn(:,2),fcsParams.freq);
fcsParams.ctnNb.nTotServoOut02 = interp1(n02totServoOut(:,1),n02totServoOut(:,2),fcsParams.freq);
%%%HOM20
fcsParams.ctnNb.nTotServoIn20 = interp1(n20totServoIn(:,1),n20totServoIn(:,2),fcsParams.freq);
fcsParams.ctnNb.nTotServoOut20 = interp1(n20totServoOut(:,1),n20totServoOut(:,2),fcsParams.freq);


%% Output

assignin('base', 'fcsParams', fcsParams);