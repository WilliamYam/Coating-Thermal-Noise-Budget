%Saves data for CTN noise curves into the file ctnData

clear

%root = fileparts(mfilename('fullpath'))

rowDataDir = [NbSVNroot 'CTN_EXP\DATA\RecordedData\']; %dir of recorded data (asd & tf)
saveDataDir = [NbSVNroot 'CTN_EXP\DATA\'];             %dir where ctnData.mat is saved
%% Transfer Function- SERVO

% units: [dB]
% measured at servo output
%%% mode00 (William servo)
h00OLMag = importdata([rowDataDir, '00tolm.asc'], ' ', 17);  % [dB] Mag   
h00OLPh  = importdata([rowDataDir, '00told.asc'], ' ', 17);  % [deg] Phase
%%% HOM02 (SR560)
h02OLMag = importdata([rowDataDir, '02tfm.asc'], ' ', 17);
h02OLPh  = importdata([rowDataDir, '02tfd.asc'], ' ', 17);
%%% HOM20 (SR560)
h20OLMag = importdata([rowDataDir, '20tfm.asc'], ' ', 17);
h20OLPh  = importdata([rowDataDir, '20tfd.asc'], ' ', 17);

% units: [dB]
% source: ???
h00ServoMag = importdata([rowDataDir, '00stm.asc'], ' ', 17);
h00ServoPh  = importdata([rowDataDir, '00std.asc'], ' ', 17);

h00OLMag = h00OLMag.data;
h00OLPh = h00OLPh.data;
h02OLMag = h02OLMag.data;
h02OLPh = h02OLPh.data;
h20OLMag = h20OLMag.data;
h20OLPh = h20OLPh.data;
h00ServoMag = h00ServoMag.data;
h00ServoPh = h00ServoPh.data;

%% Servo Noise

% units: V/rtHz
% measure at the output of the fast channel
n00sServoOut = importdata([rowDataDir, '00sn.asc'], ' ', 14);  % 00
n02sServoOut = importdata([rowDataDir, '02sn.asc'], ' ', 14);  % 02
n20sServoOut = importdata([rowDataDir, '20sn.asc'], ' ', 14);  % 20

n00sServoOut = n00sServoOut.data; %interp1(n00sServoOut.data(:, 1), n00sServoOut.data(:, 2), n00PDServoIn(:, 1));
n02sServoOut = n02sServoOut.data;
n20sServoOut = n20sServoOut.data;

%% PD dark noise
% units: V/rtHz
% measured after Mixer
n00PDServoIn = importdata([rowDataDir, '00pd.asc'], ' ', 14);  % 00 
n02PDServoIn = importdata([rowDataDir, '02pd.asc'], ' ', 14);  % 02
n20PDServoIn = importdata([rowDataDir, '20pd.asc'], ' ', 14);  % 20

n00PDServoIn = n00PDServoIn.data;
n02PDServoIn = n02PDServoIn.data;
n20PDServoIn = n20PDServoIn.data;

%% Marconi Noise
% units: V/rtHz
% measured at resonant freqs of HOM02/20 (phase detector ...???)
% AOM driver noise not included
n02Marconi = importdata([rowDataDir, '02mn.asc'], ' ', 14); % 02
n20Marconi = importdata([rowDataDir, '20mn.asc'], ' ', 14); % 20

n02Marconi = n02Marconi.data;
n20Marconi = n20Marconi.data;

%% Toatl Loop Noise 
% units: V/rtHz
% Measured at closed loop at the input and output of the servo, respectively
%%% 00
n00totServoIn  = importdata([rowDataDir, '00snin.asc'], ' ', 14);    
n00totServoOut = importdata([rowDataDir, '00snout.asc'], ' ', 14);
%%% 02
n02totServoIn  = importdata([rowDataDir, '02nsin.asc'], ' ', 14);
n02totServoOut = importdata([rowDataDir, '02nsout.asc'], ' ', 14);
%%% 20
n20totServoIn  = importdata([rowDataDir, '20nsin.asc'], ' ', 14);
n20totServoOut = importdata([rowDataDir, '20nsout.asc'], ' ', 14);

n00totServoIn  = n00totServoIn.data;
n00totServoOut = n00totServoOut.data;
n02totServoIn  = n02totServoIn.data;
n02totServoOut = n02totServoOut.data;
n20totServoIn  = n20totServoIn.data;
n20totServoOut = n20totServoOut.data;

f = n00PDServoIn(:, 1);

save([saveDataDir, 'ctnData']);