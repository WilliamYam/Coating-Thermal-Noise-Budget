
function ctnParams

%ctnParms  Defines parameters for the HOM20.mdl Simulink model
% mode = 'data' or 'model'
% 'data'refers to measured quantity whereas 'model' to expected value of
% the same quantity.
% It outputs to a variable called "fclParams" in the matlab workspace.
% 
% based on the data by William, September 2014


%% Common Parameters
fcsParams.paramsFileName = mfilename('fullpath');
%fcsParams.name = 'HOM20';
fcsParams.freq = 0:2:100000; %logspace(log10(5),log10(1600),1000);

if exist('NbSVNroot.m', 'file') ~= 2
    error('Please add the NbSVN''s Common/Utils folder to your MATLAB path');
end
%NbSVNroot
noiseModelDir = [NbSVNroot 'Common\Utils\NoiseModel'];    %important to have it
ModelDir = [NbSVNroot 'CTN_EXP\Data\'];     % storage data directory                 
currentDir = pwd;

% dataDir.tf = 'CTN_Data/trunk/';
% dataDir.cds = '/opt/rtcds/userapps/release/';
% svnDir.cal = '/ligo/svncommon/CalSVN/aligocalibration/trunk/Runs/S7/';
% quadModelDir = [svnDir.sus 'Common/SusModelTags/Matlab/'];
% quadModelProductionDir = [svnDir.sus 'QUAD/Common/MatlabTools/QuadModel_Production'];
% quadFilterDir = [svnDir.sus 'QUAD/Common/FilterDesign/'];
% calToolsDir = [svnDir.cal 'Common/MatlabTools/'];
% quadLisoDir = [NbSVNroot 'Dev/SusElectronics/LISO/QUAD/'];
% 
% currentDir = pwd;
% 
% fileName.quadModel  = [quadModelDir 'quadmodelproduction-rev3767_ssmake4pv2eMB5f_fiber-rev3601_fiber-rev3602_released-2013-01-31.mat'];
% fileName.dampFilters = [quadFilterDir 'MatFiles/dampingfilters_QUAD_2013-05-01.mat'];
% fileName.darmFilters = [quadFilterDir 'HierarchicalControl/2013-01-08_DARMQUAD_HierDesign.mat'];
% 
% ifoParams.filterDir.sus = [svnDir.cds 'sus/' ifoParams.name '/filterfiles/'];
% ifoParams.filterDir.isc = [svnDir.cds 'isc/' ifoParams.name '/filterfiles/'];
% ifoParams.act.filterfiles.etmx = [ifoParams.filterDir.sus ifoParams.name 'SUSETMX.txt'];
% ifoParams.act.filterfiles.etmy = [ifoParams.filterDir.sus ifoParams.name 'SUSETMY.txt'];
% ifoParams.dig.filterFiles.lsc = [ifoParams.filterDir.isc ifoParams.name 'LSC.txt'];

%%  Data loading

cd(ModelDir)
load('ctnData.mat') 
cd(currentDir)

%% Common Parameters
% 
fcsParams.common.c             = 299792458;     % speed of light  [m/s]
fcsParams.common.wavelength    = 1064e-9;        % laser wavelength [m]
fcsParams.common.e_ch          = 1.602e-19;     % charge per electron [C/electron]
fcsParams.common.h             = 6.626e-34;     % Planck's constant [J/s]
fcsParams.common.laserFreq     = fcsParams.common.c /...
                                 fcsParams.common.wavelength;   %laser light freq.

%% Cavity Parameters
% 
fcsParams.cavity.Length           = 0.095;                                    % [m] cavity length 
fcsParams.cavity.RoC1             = 0.050;                                    % [m] input coupler radius of curvature 
fcsParams.cavity.RoC2             = 0.050;                                    % [m] output coupler radius of curvature 
fcsParams.cavity.R1               = 1-200e-6;                                 % Reflectivity of input couplers
fcsParams.cavity.R2               = 1-200e-6;                                 % Reflectivity of end couplers
fcsParams.cavity.FSR              = fcsParams.common.c /...
                                    (2 * fcsParams.cavity.Length);              %FSR [Hz]
fcsParams.cavity.LightTransitTime = fcsParams.cavity.Length /...
                                    fcsParams.common.c ;                       % transit time per bounce [s]
%%%% Finesse, FWHM, Pole
            %-------- Finesse function def.-------------------------
                Fin = @(R1,R2)((pi*(R1*R2)^(1/4))/(1-sqrt(R1*R2)));
            %-------------------------------------------------------
            
fcsParams.cavity.Finesse = Fin(fcsParams.cavity.R1,fcsParams.cavity.R2);       % expected cavity finesse

  
      fcsParams.cavity.FWHM    = fcsParams.cavity.FSR /fcsParams.cavity.Finesse;     % [Hz] expected Full Width at Half Maximum    
      fcsParams.cavity.FWHM    =  289e3;                                             % [Hz] measured value of FWHM
      fcsParams.cavity.Finesse =  fcsParams.cavity.FSR/fcsParams.cavity.FWHM;   
  
       
fcsParams.cavity.Pole    = fcsParams.cavity.FWHM/2;                                  % [Hz] expected cavity pole

%%%% Gouy Phase

  %-------- Oneway Gouy phase def.----------------------------------------
   Gouy = @(n,m,L,RoC1, RoC2)((n+m+1)*acos(-sqrt((1-L/RoC1)*(1-L/RoC1))));
  %-----------------------------------------------------------------------

  fcsParams.cavity.Gouy00 = 2 * Gouy(0, 0, fcsParams.cavity.Length,...
                                     fcsParams.cavity.RoC1,...
                                     fcsParams.cavity.RoC1);                        % [rad]  Rounttrip Gout phase for 00
  fcsParams.cavity.Gouy02 = 2 * Gouy(0, 2, fcsParams.cavity.Length,...
                                     fcsParams.cavity.RoC1,...
                                     fcsParams.cavity.RoC1);                        % [rad]  Rounttrip Gout phase for 02
                                 
   fcsParams.cavity.Gouy20 = 2 * Gouy(2, 0, fcsParams.cavity.Length,...
                                     fcsParams.cavity.RoC1,...
                                     fcsParams.cavity.RoC1);                        % [rad]  Rounttrip Gout phase for 20

%% Cavity beam 
%

fcsParams.beam.PwrInc00   =    0.355e-3;                      % [W] incident Gaussian on input coupler
fcsParams.beam.PwrInc02   =    0.105e-3;                      % [W] incident HOM02 on input coupler
fcsParams.beam.PwrInc20   =    0.105e-3;                      % [W] incident HOM20 on input coupler
fcsParams.beam.Coupling00   =   0.20;                         % cavity couppling of 00 
fcsParams.beam.Coupling02   =   0.0795;                       % cavity couppling of 02
fcsParams.beam.Coupling20   =   0.0778;                       % cavity couppling of 20


PwrCpl00 = fcsParams.beam.PwrInc00 * fcsParams.beam.Coupling00;    % [W]  power coupled to cavity 00
PwrCpl02 = fcsParams.beam.PwrInc02 * fcsParams.beam.Coupling02;    % [W]  power coupled to cavity 02
PwrCpl20 = fcsParams.beam.PwrInc20 * fcsParams.beam.Coupling20;    % [W]  power coupled to cavity 20

fcsParams.beam.PwrCir00 = fcsParams.beam.PwrInc00 * ...
                          fcsParams.beam.Coupling00 *...
                          fcsParams.cavity.Finesse/pi;                  % [W] circulating power of 00 in the cavity
                      
fcsParams.beam.PwrCir02 = fcsParams.beam.PwrInc02 * ...
                          fcsParams.beam.Coupling02 *...
                          fcsParams.cavity.Finesse/pi;                  % [W] circulating power of 02 in the cavity 
                      
fcsParams.beam.PwrCir20 = fcsParams.beam.PwrInc20 * ...
                          fcsParams.beam.Coupling20 *...
                          fcsParams.cavity.Finesse/pi;                  % [W] circulating power of 20 in the cavity

%% PDH - Error Signal

%%% Phase Modulation Properties
fcsParams.errSig.beta00 = 0.46;                  % Modulation depth for 00
fcsParams.errSig.beta02 = 0.35;                  % Modulation depth for 02
fcsParams.errSig.beta20 = 0.35;                  % Modulation depth for 20
%%% Modulation Frequency
fcsParams.errSig.modFreq00 = 29.00e6;            % Modulation frequency for 00
fcsParams.errSig.modFreq02 = 27.61e6;            % Modulation frequency for 02
fcsParams.errSig.modFreq20 = 17.23e6;            % Modulation frequency for 20
%%% Round trip phase for sidebands
phi_mod00 = 2*pi*2*fcsParams.cavity.Length*fcsParams.errSig.modFreq00/fcsParams.common.c;   %------------------check this!!!!
phi_mod02 = 2*pi*2*fcsParams.cavity.Length*fcsParams.errSig.modFreq02/fcsParams.common.c;   % made as roundtrip phase
phi_mod20 = 2*pi*2*fcsParams.cavity.Length*fcsParams.errSig.modFreq20/fcsParams.common.c;


%%% Cavity Roundtrip Phase [rad] (vector for plot)
phi_cav = linspace(-pi/1000,pi/1000,10001);

%%% The Error Signal [W] (demod phase = 90deg, sidebands outside linewidth, want I)
Err00 = PDH_Esig(fcsParams.cavity.R1,fcsParams.cavity.R2,...
                                  fcsParams.beam.PwrInc00,phi_mod00,...
                                  fcsParams.errSig.beta00,pi/2,phi_cav);      %PDH error signal for 00 used for plot
Err02 = PDH_Esig(fcsParams.cavity.R1,fcsParams.cavity.R2,...
                                  PwrCpl02,phi_mod02,...
                                  fcsParams.errSig.beta02,pi/2,phi_cav);      %PDH error signal for 02 used for plot
Err20 = PDH_Esig(fcsParams.cavity.R1,fcsParams.cavity.R2,...
                                  PwrCpl20,phi_mod20,...
                                  fcsParams.errSig.beta20,pi/2,phi_cav);      %PDH error signal for 20 used for plot

errSig00_pk2pk = 2*max(Err00);        % [W] ppk-pk error signal for 00
errSig02_pk2pk = 2*max(Err02);        % [W] ppk-pk error signal for 02
errSig20_pk2pk = 2*max(Err20);        % [W] ppk-pk error signal for 20

 % [W/rad] gradient of the Error Signal 
grad_Err00 = abs(gradient(Err00)./gradient(phi_cav));                        
grad_Err02 = abs(gradient(Err02)./gradient(phi_cav));
grad_Err20 = abs(gradient(Err20)./gradient(phi_cav));

%%% Cavity Response (Error Signal slope) 
fcsParams.errSig.rad2W00e = max(grad_Err00);                                % [W/rad] (esimated)
fcsParams.errSig.rad2W00m = 0.5242*fcsParams.beam.Coupling00;               % [W/rad] (measured)
fcsParams.errSig.rad2W02e = max(grad_Err02) * fcsParams.beam.Coupling00;    % [W/rad]
fcsParams.errSig.rad2W02m = 0.0284 * fcsParams.beam.Coupling02;
fcsParams.errSig.rad2W20e = max(grad_Err20)*fcsParams.beam.Coupling00;      % [W/rad]
fcsParams.errSig.rad2W20m = 0.0210 * fcsParams.beam.Coupling20;

%fcsParams.errSig.rad2W02 = (360 / 50) mV / 20 kHz / gHztL / gPD02 / gCoupling02 (measured slope)


%% PD and Mixer parameters

%%%Mixer gain
fcsParams.PD.G_Mixer = 1;            % mixer gain Vdc/Vref for all beams
%%% 1811
PDtranimp00 = 0.8 * 4e4;             % [A / W * Vrf / A]   PDgain for 00
%%% LSC RF PD 
PDtranimp02 = 4.0e4;                 % [V/A] transimpedance at 17.23MHz 
PDtranimp20 = 2.0e4;                 % [V/A] transimpedance at 27.61MHz 

%transimpedance after mixer
fcsParams.PD.PDrespTot00 = PDtranimp00 * fcsParams.PD.G_Mixer;    % [V/W]
fcsParams.PD.PDrespTot02 = PDtranimp02 * fcsParams.PD.G_Mixer;    % [V/W]
fcsParams.PD.PDrespTot20 = PDtranimp20 * fcsParams.PD.G_Mixer;    % [V/W]

%G_rf2I = 1/3;                      %What is it?!

%% Opt Gain

%%% error signal slope
  % fcsParams.OptGain.Vrad00 = fcsParams.errSig.rad2W00 * fcsParams.PD.PDrespTot00;  % [V/rad]
  % fcsParams.OptGain.Vrad02 = fcsParams.errSig.rad2W02 * fcsParams.PD.PDrespTot02;
  % fcsParams.OptGain.Vrad20 = fcsParams.errSig.rad2W00 * fcsParams.PD.PDrespTot20;
  % fcsParams.OptGain.VHz00  = fcsParams.OptGain.Vrad00 * 2 * pi *...
  %                            2 * fcsParams.cavity.Length / fcsParams.common.c ;    % [V/Hz]   2L_cav?
  % fcsParams.OptGain.VHz02  = fcsParams.OptGain.Vrad02 * 2 * pi *...
  %                            2 * fcsParams.cavity.Length / fcsParams.common.c ;
  % fcsParams.OptGain.VHz20  = fcsParams.OptGain.Vrad20 * 2 * pi *...
  %                            2 * fcsParams.cavity.Length / fcsParams.common.c ; 
  % fcsParams.OptGain.Vm00   = fcsParams.OptGain.Vrad00 * 2 * pi /...
  %                            fcsParams.common.wavelength;                            % [V/m] 
  % fcsParams.OptGain.Vm02   = fcsParams.OptGain.Vrad02 * 2 * pi /...
  %                            fcsParams.common.wavelength; 
  % fcsParams.OptGain.Vm20   = fcsParams.OptGain.Vrad20 * 2 * pi /...
 %                            fcsParams.common.wavelength;
                       
%%%laser controller gain (fast channel)                      
fcsParams.OptGain.laserFast      = 5e6;                                            % [Hz/V]

%%%Marconi gain
fcsParams.OptGain.PhaseDetectorGain02  =  4e-7;                                    % [V/Hz] ???????? (for the Marconi noise measurement)
fcsParams.OptGain.PhaseDetectorGain20  =  4e-7;  
fcsParams.OptGain.MarconiGain        = 10e3 / sqrt(2);                             % [Hz/V], note: Marconi external modulation per Vrms

%%%Frequency 2 roundtripPhase
fcsParams.OptGain.Hz2rad  = 4 * pi * fcsParams.cavity.Length /...
                                   fcsParams.common.c;                             % [rad/Hz] roundtrip phase (longitudonal wave)                                   fcsParams.common.c;  
%%%Lenght 2 roundtripPhase
fcsParams.OptGain.m2rad    =  4 * pi / fcsParams.common.wavelength;                % [rad/m]  Length2phase conversion

%%%% GouyPhase contribution (to be completed) 
% fcsParams.OptGain.GouyContr02 = fcsParams.cavity.Gouy02 /...                     % [rad/Hz] Gouyphase contribution to 02
%                                    fcsParams.common.c;   
% fcsParams.OptGain.GouyContr20 = fcsParams.cavity.Gouy20 /...                     % [rad/Hz] Gouyphase contribution to 02
% 
%% Extras
%%% pk-pk error signal in V
fcsParams.errSig.Err00_Vpk2pk = errSig00_pk2pk * fcsParams.PD.PDrespTot00;  % [V] erros signal pk-pk
fcsParams.errSig.Err02_Vpk2pk = errSig02_pk2pk * fcsParams.PD.PDrespTot02;
fcsParams.errSig.Err20_Vpk2pk = errSig20_pk2pk * fcsParams.PD.PDrespTot20;

%% Plot (Error signals)
% % 
% 
% figure(100)
% SR560gain = 50;                                      %SR560 gain before scope
% plot(phi_cav,Err00 * fcsParams.PD.PDrespTot00 * SR560gain, '-.', 'LineWidth', 2)
% hold on
% plot(phi_cav,Err02 * fcsParams.PD.PDrespTot02 * SR560gain, 'r', 'LineWidth', 2)
% plot(phi_cav,Err20 * fcsParams.PD.PDrespTot20 * SR560gain, 'k', 'LineWidth', 2)
% xlabel('Cavity Roundtrip Phase [rad]')
% ylabel('Error Signal [V]')
% legend('Gaussian','HOM02','HOM20')
% grid  on
% text(phi_cav(105),3,['Amp. gain = ' num2str(SR560gain)],'fontsize',16)
% text(phi_cav(105),2,[num2str(SR560gain * fcsParams.errSig.Err00_Vpk2pk),' Vpk-pk',10,...
%                                   num2str(SR560gain * fcsParams.errSig.Err02_Vpk2pk,2),' Vpk-pk',10,...
%                                   num2str(SR560gain * fcsParams.errSig.Err20_Vpk2pk,2),' Vpk-pk']...
%                                   ,'fontsize',16)
%                                                                     
% set(gca,'fontsize',20)

%% Servo Parameters
   
%%%00
%when integrator and boost off- used for test
gain00        = -33.92;                       % dB measured gain at 
freq00        = 8e4;                          % Hz this trequency
fcsParams.servo00off.zeros       = [1e6];       % Hz
fcsParams.servo00off.poles       = [30];         % Hz
fcsParams.servo00off.gain        = find_K(fcsParams.servo00off.zeros,...
                                       fcsParams.servo00off.poles,...
                                       gain00, freq00);         % dB
gain00        = -33.92;                         % dB measured gain at 
freq00        = 8e4;                            % Hz this trequency
fcsParams.servo00.zeros       = [10e3];         % Hz
fcsParams.servo00.poles       = [0,0];          % Hz
fcsParams.servo00.gain        = find_K(fcsParams.servo00.zeros,...
                                       fcsParams.servo00.poles,...
                                       gain00, freq00);         % dB
%%%HOM02
gain02        = 20*log10(2e5);                  % dB measured gain at 
freq02        = 0;                              % Hz this trequency
fcsParams.servo02.zeros       = [];             % Hz
fcsParams.servo02.poles       = [100e3, 30];    % Hz
fcsParams.servo02.gain        = find_K(fcsParams.servo02.zeros,...
                                       fcsParams.servo02.poles,...
                                       gain02, freq02);         % dB
%%%HOM20
gain20        = 20*log10(2e5);                  % dB measured gain at 
freq20        = 0;                              % Hz this trequency
fcsParams.servo20.zeros       = [];             % Hz
fcsParams.servo20.poles       = [100e3, 30];    % Hz
fcsParams.servo20.gain        = find_K(fcsParams.servo20.zeros,...
                                       fcsParams.servo20.poles,...
                                       gain20, freq20);         % dB

%% Transfer Function (measured)
% measured at the closed loop

%%%Gaussian
fcsParams.TF.TFmag00 = interp1(h00OLMag(:,1),h00OLMag(:,2),fcsParams.freq);
fcsParams.TF.TFph00 = interp1(h00OLPh(:,1),h00OLPh(:,2),fcsParams.freq);
%%%HOM02
fcsParams.TF.TFmag02 = interp1(h02OLMag(:,1),h02OLMag(:,2),fcsParams.freq);
fcsParams.TF.TFph02 = interp1(h02OLPh(:,1),h02OLPh(:,2),fcsParams.freq);
%%%HOM20
fcsParams.TF.TFmag20 = interp1(h20OLMag(:,1),h20OLMag(:,2),fcsParams.freq);
fcsParams.TF.TFph20 = interp1(h20OLPh(:,1),h20OLPh(:,2),fcsParams.freq);
assignin('base', 'fcsParams', fcsParams);

