

open_system('ctnFCS')
ctnParams;
ctnNbParams;
% io(1)=linio('ctnFCS/00 FCL/Sum1',1,'openinput');
% io(2)=linio('ctnFCS/00 FCL/Servo',1,'openoutput');
io(1)=linio('ctnFCS/00 FCL/Sum1',1,'looptransfer');

setlinio('ctnFCS',io);
%setlinio('ctnFCS/00 FCL',io)
systest = linearize('ctnFCS',io);
bode(systest)


figure(100)
semilogx(fcsParams.freq,fcsParams.TF.TFmag00)
grid on
hold on

gain00        = -33.92;                         % dB measured gain at 
freq00        = 8e4;                            % Hz this trequency
fcsParams.servo00.zeros       = [10e3];         % Hz
fcsParams.servo00.poles       = [0,0];          % Hz
fcsParams.servo00.gain        = find_K(fcsParams.servo00.zeros,...
                                       fcsParams.servo00.poles,...
                                       gain00, freq00);  

k = 10^(fcsParams.servo00.gain/20);   % unitless
G=freqresp(zpk(-2 * pi * fcsParams.servo00.zeros, -2 * pi * fcsParams.servo00.poles,k),fcsParams.freq,'Hz');

for ii= 1:size(fcsParams.freq,2)    
    g(ii)= 20*log10(abs(G(1,1,ii))); 
end
semilogx(fcsParams.freq,g,'r')







open_system('ctnFCS')
ctnParams;
ctnNbParams;
io(1)=linio('ctnFCS/SystemNoise/Sum1',1,'openinput');
io(2)=linio('ctnFCS/02 FCL/Cavity02/Sum1',1,'openoutput');
%io(1)=linio('ctnFCS/02 FCL/Sum1',1,'looptransfer');

setlinio('ctnFCS',io);
%setlinio('ctnFCS/00 FCL',io)
systest = linearize('ctnFCS',io);
bode(systest)
 



sys_io(1)=linio('watertank/Subsystem/PID Controller',1,'input');
sys_io(2)=linio('watertank/Subsystem/Water-Tank System',1,'openoutput');

linsys = linearize('watertank',sys_io);

bode(linsys)