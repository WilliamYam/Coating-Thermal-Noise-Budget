function testParams(a)


%% Common Parameters
fcsParams.paramsFileName = mfilename('fullpath');
fcsParams.name = 'HOM20';
fcsParams.freq = logspace(log10(5),log10(1600),1000);

%% Common Parameters
% 
fcsParams.c             = 299792458;     % speed of light  [m/s]
fcsParams.wavelength    = 1064e-9;        % laser wavelength [m]
fcsParams.cavityLength  = 0.095;         % [m]
fcsParams.e_ch          = 1.602e-19;     % charge per electron [C/electron]
fcsParams.h             = 6.626e-34;     % Planck's constant [J/s]
fcsParams.cavityLightTransitTime = fcsParams.cavityLength/fcsParams.c; % per bounce [s]
fcsParams.FSR = fcsParams.c/(2 * fcsParams.cavityLength);  %[Hz]

if strcomp(a, 'dd')==1
    fcsParams.FSR =2;
end
assignin('base', 'fcsParams', fcsParams);