function n = omcnoise(par,freq)
    
    load DCPD_noise100_L1.mat % Load measured DCPD output noise, Z = 100 ohms [V]
    n.PreampA = interp1(f,dcpd1_100,freq);
    n.PreampB = interp1(f,dcpd2_100,freq);
    
    n.Shot = sqrt(2*par.constants.hnu*par.Pin);
    
    load ISS2_OOL_10_17_13.mat
    n.Intensity = interp1(f,RIN*par.Pin,freq);

end