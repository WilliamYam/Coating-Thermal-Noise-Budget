%% HOM20 cavity parameters

global c electronch h L_cav lambda P_hom20 p_cav

c = 299792458;            % Speed of Light [m/s]
electronch = 1.602e-19;   % charge per electron [C/electron]
h = 6.626e-34;            % Planck's constant [J/s]

L_cav     = 0.095;          % Folded Cavity Length [m] 
lambda = 1064e-9;          % Laser wavelength [m]



RF_Marconi = 10e3;               % Hz/V 
R_cp = 1-200e-6;                 % Reflectivity of both couplers


P_hom20 = 50e-3;          % Incident Power [W]

FSR = c/2/L_cav;      % Free Spectral Range [Hz]

%%% Optical properties
% Finesse
Fin = @(R1,R2)((pi*(R1*R2)^(1/4))/(1-sqrt(R1*R2)));
Fin_cav = Fin(R_cp,R_cp);


FWHM_cav = FSR/Fin_cav;            % Full Width at Half Maximum (FWHM)


p_cav = FWHM_cav/2;                   % Cavity pole

P_hom20_circ = P_hom20 * Fin_cav/pi;  % Circulating power in the cavity

%Pick-off Ratio to the PD
R_pickoff = 0.008;
%R_pickoff = 0.004;
%% Error Signal

%%% Phase Modulation Properties
beta_mod = 0.35;                  % Modulation depth
nu_mod = 27.61e6;                  % Modulation frequency
phi_mod = 2*pi*2*L_cav*nu_mod/c;   %------------------check this!!!!

%%% Cavity Roundtrip Phase [rad] (vector)
phi_cav = linspace(-pi,pi,10001);

%%% The Error Signal [W]
Err_cav = PDH_Esig(R_cp,R_cp,P_hom,phi_mod,beta_mod,pi/2,phi_cav);
%%% (demod phase = 90deg, sidebands outside linewidth, want I)

%%% The Gradient of the Error Signal [W/rad]
grad_Err = abs(gradient(Err_cav)./gradient(phi_cav));

%%% Response of Error Signal on cavity around resonance %[W/rad]
lin_Err = max(grad_Err);
 
%% PD and Mixer parameters

G_Mixer = 1;     %mixer gain Vdc/Vref 

%%% LSC RF PD response @ 27.61MHz [V/W] (still not sure about)
 
pdresp = 0.72;                    %Apx. Responsivity [A/W] ???? (not used parm)

PDtranimp = 9e3;                   %  transimpedance at 27.61MHz [V/A]
PDresp_tot = PDtranimp * G_Mixer;

G_rf2I = 1/3;                      %What is it?!

%% Opt Gain

OptGain.W.rad = lin_Err;
OptGain.W.Hz = lin_Err*2*pi*L_cav/c;
OptGain.W.m = lin_Err*2*pi/lambda;

OptGain.V.rad = lin_Err*PDresp_tot;
OptGain.V.Hz = lin_Err*PDresp_tot*2*pi*L_cav/c;
OptGain.V.m = lin_Err*PDresp_tot*2*pi/lambda;
% Plot

% figure(100)
% plot(phi_cav,Err_cav)
% xlabel('Cavity Roundtrip Phase [rad]')
% ylabel('Error Signal [W]')
% text(phi_cav(105),0.8*max(Err_cav),[num2str(OptGain.W.Hz,2),' W/Hz',10,...
%                                       num2str(OptGain.W.m,2),' W/m']...
%                                       ,'fontsize',16)
% %text(phi_cav(6105),0.8*max(Err),[num2str(OptGain.A.Hz,2),' A/Hz',10,...
% %                                      num2str(OptGain.A.m,2),' A/m']...
% %                                      ,'fontsize',16)
% text(phi_cav(6105),-0.8*max(Err_cav),[num2str(OptGain.V.Hz,2),' V/Hz',10,...
%                                       num2str(OptGain.V.m,2),' V/m']...
%                                       ,'fontsize',16)                                 
% set(gca,'fontsize',20)


%% Switches

% MC-L digital filters
% MICH.FM1 = -4000 * comp3 * comp3;
% MICH.FM2 = comp11;
% MICH.FM3 = comp33;
% MICH.FM4 = comp4;
% MICH.FM5 = 1;
% MICH.FM6 = notch1;
% MICH.FM7 = notch2;
% MICH.FM8 = 1;
% MICH.FM9 = zpk(-2*pi*20, -2*pi*50,50/20);
% MICH.FM10 = 1;

fss_ugf = 600e3;
FSSolg =  zpk(-2*pi*[80e3], -2*pi*[0 0 15e6 15e6 15e6 15e6], 1);
[m,p] = bode(FSSolg, 2*pi*fss_ugf);
FSSolg = FSSolg/m;
FSSresp = FSSolg/(1 + FSSolg);




