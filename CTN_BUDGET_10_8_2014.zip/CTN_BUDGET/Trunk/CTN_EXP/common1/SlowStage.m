%% Slow

nV = 1.7e-9;
nI = 1.5e-12;

Kb = 1.3806503e-23;     %Boltzmans constant (J/K or V^2/Hz/Ohm/K) 
T = 273 + 25;        %Room Temperature (K)

%%% Generic Filter Stage
R164 = 48.7e3;
R165 = 48.7e3;
R166 = 2e3;
C248 = 1e-9;
C249 = 1e-9;
C245 = 330e-9;
C246 = 330e-9;

vdivider = tf([R165*R166*(C246+C249) R166],[R165*R166*(C246+C249) 2*R165+R166]);


R160 = 3.32e3;
C242 = 180e-12;
R158 = 374;

oamp = tf([R158*R160*C242 R158+R160],[R158*R160*C242 R158]);

gfilter = oamp*vdivider;

%%% Before Slow output
R170 = 3.32e3;
R168 = 16.5e3;
C261 = 4.7e-9;
R172 = 100;

slowout = tf([R168],[R168*R170*C261 R170]);     %not right!!!

%%% Last Gain stage G=10
R157 = 33.2e3;
C243 = 10e-12;
R161 = 3.32e3;
R162 = 100;