function [phitot, D] = lossfunc(f)

% coefficients
E = 2.119e+11;
Tw = 300;
rho_v = 7800; 
C = 486;
alpha = 12e-6;
beta = -2.5e-4;
radi = 5.97e-5;
T = 28.4587/4;        % tension per wire, N
sigma = T/radi^2/pi;  % stress
kappa = 49; 

amp =1;
phi_s =2e-4;
tau =  4 *  0.0737472 * C * radi^2 * rho_v/kappa;


%%

phi_t = E*Tw/rho_v/C * (alpha-sigma*beta/E)^2 * 2*pi*f * tau * amp ./ (1+(2*pi*f*tau).^2);

phitot = phi_s + phi_t;

a =  0.000545;
L = 0.22;
n = [1:3]';
D = 2*a/L * (1+n.^2 *pi^2 *a/2/L);

