% get the wipf 
addpath(genpath('../../Common/Utils/'))


freq = logspace(0,4,300);

% load params

par = omcparams;

n = omcnoise(par,freq);

% wipf noise magic

[noises, sys] = nbFromSimulink('OMC', freq, 'dof', 'P');

%% Make an NB plot

disp('Plotting noises')
nb = nbGroupNoises('OMC', noises, sys);
nb.sortModel();
matlabNoisePlot(nb);